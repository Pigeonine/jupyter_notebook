package com.spring.jpa;

import java.time.LocalDateTime;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.spring.jpa.entity.Board;
import com.spring.jpa.entity.Custom;
import com.spring.jpa.entity.Role;
import com.spring.jpa.repository.BoardRepository;
import com.spring.jpa.repository.CustomRepository;
import com.spring.jpa.repository.RoleRepository;

import jakarta.transaction.Transactional;

@SpringBootApplication
public class Sp04JpqlApplication implements CommandLineRunner{
	
	@Autowired
	private CustomRepository  customRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private BoardRepository boardRepository;
	
	@Transactional
	@Override
	public void run(String... args) throws Exception {
		
		//boardRepository.findAll()
		
		//모든 게시글 검색...JPQL...조인
		/*
		boardRepository.getBoards()
			           .forEach(b->{
			        	   System.out.println(b);
			        	   System.out.println(b.getCustom());
			           });
		*/
		//Role이 Admin인 권한을 가지는 사용자를 추가.
		/*
		Role role=roleRepository.findById(2).get();
		
		Custom c = new Custom();
		c.setName("DDD");
		c.setPassword("ddd");
		c.setEmail("ddd.google.com");
		c.setRegDate(LocalDateTime.now());
		
		c.setRoles(Set.of(role));//엔터티간의 관계(DI, Has a Relation, Setter)
		
		customRepository.save(c);
		*/
		
		//관리자 권한을 가지는 4(DDD)번 고객이 게시글을 추가
		/*
		Custom c=customRepository.findById(4).get();
		Board b = new 	Board();
		b.setTitle("공지");
		b.setContent("다음주 월요일은 쉽니다");
		b.setRegDate(LocalDateTime.now());
		b.setCustom(c); //Entity주입이 일어난다.
		
		boardRepository.save(b);
		*/
		
		boardRepository.getBoards("ROLE_ADMIN")
						.forEach(b->{
							System.out.println(b);
							System.out.println(b.getCustom().getRoles());
						});
		
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Sp04JpqlApplication.class, args);
	}
}
















