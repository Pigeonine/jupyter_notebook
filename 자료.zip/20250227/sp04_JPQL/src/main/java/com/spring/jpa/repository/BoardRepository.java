package com.spring.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.spring.jpa.entity.Board;

public interface BoardRepository extends JpaRepository<Board, Long>{

	/*
	 * JPQL
	 * SQL처럼 보이지만 SQL이 아니다.
	 * 객체지향 언어이다.
	 * JPQL에서 from절 뒤에 나오는 것은 테이블 명이 아니라 엔터티 클래스명이 온다!!!
	 * 
	 * SELECT b FROM board b (X)
	 * SELECT b FROM Board b (O)
	 */
	//@Query(value = "SELECT b FROM Board b")
	//@Query(value = "SELECT b FROM Board b JOIN b.custom") //조인사용
	
	//JOIN FETCH :: 조인하면서 연관된 정보를 다 바당오는 기술
	//N+1문제를 해결하려면 일반 조인문이 아닌 jpql join fetch를 사용해야 한다. b.custom.customId 의 의미
	@Query(value = "SELECT b FROM Board b JOIN FETCH b.custom") //펫치조인 사용
	//@Query(value = "SELECT b FROM Board b JOIN Custom c ON b.custom.customId = c.customId") //일반적인 조인 쿼리문
	List<Board> getBoards(); //findAll()은 잘 안쓴다.
	
	//전체 게시글의 갯수를 반환..count 함수 사용
	@Query(value="SELECT COUNT(boardId) FROM Board b")//디비 컬럼명이 아닌 @Id로 지정된 필드명
	Long getBoardCount();
	
	//관리자권한을 가진 사람이 쓴 게시글 정보를 검색 
	@Query(value="SELECT b FROM Board b join fetch b.custom c join fetch c.roles r where r.name= :roleName") //jpql에서는 ?가 없다
	List<Board> getBoards(@Param("roleName") String roleName);
}




















