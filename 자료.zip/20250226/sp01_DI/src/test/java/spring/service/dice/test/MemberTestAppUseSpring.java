package spring.service.dice.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

import spring.service.dao.MemberDAO;
import spring.service.dao.impl.MemberDAOImpl;
import spring.service.dice.play.Player02;
import spring.service.vo.Member;
public class MemberTestAppUseSpring {
	public static void main(String[] args) {
		//DIContainer가 설정문서를 읽어서 빈을 생성 + 보관한다
		ApplicationContext factory = 
				new ClassPathXmlApplicationContext("./config/member.xml");
		
		System.out.println("====================================");
		
	    
		MemberDAOImpl dao=(MemberDAOImpl)factory.getBean("memberDAOImpl");
		//화면에서 회원정보를 받았다치고 데이타값은 직접 생성
		Member member  = new Member("11", "11", "김삼성", "잠실");
		dao.register(member);
		
		dao.delete("11");
	
	}
	
}//end of class