package spring.service.dao;

import java.util.List;

import spring.service.vo.Member;

//DB Access Logic의 템플릿 기능
public interface MemberDAO {
	void register(Member vo);
	void delete(String id);
	void update(Member vo);
	Member getMember(String id);
	List<Member> getAllMember();
}
