package spring.service.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import spring.service.dao.MemberDAO;
import spring.service.vo.Member;

//실제 디비 연결하는 기능을 구현
//기능마다 Connection을 하나씩 받아서 로직이 전개됨
//하나하나의 기능이 하나하나의 클라이언트의 완벽한 요청처리 단위가된다.

//POJO :: Plain Old Java Object
//public class MemberDAOImpl implements MemberDAO{
@Repository
public class MemberDAOImpl{
	//@Override
	public void register(Member vo) {		
		System.out.println("==== register member call ====");
		System.out.println(vo.getName()+" 님이 등록되셨습니다..");
	}

	//@Override
	public void delete(String id) {		
		System.out.println("==== delete member call ====");
		System.out.println(id+" 님이 삭제되셨습니다..");
	}

	//@Override
	/*
	public void update(Member vo) {		
		
	}

	@Override
	public Member getMember(String id) {
		
		return null;
	}

	@Override
	public List<Member> getAllMember() {
		
		return null;
	}
	*/

}
