package com.spring.jpa.entity;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity //해당 클래스는 디비테이블과 매핑되는 기술
@Table(name="custom") //현재 클래스명과 테이블명일 다를때 사용
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
//@ToString
public class Custom {
	
	@Id//유일한 값 pk
	@Column(name="custom_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer customId;
	
	@Column(length = 20)
	private String password;
	
	@Column(length = 30)
	private String name;
	
	@Column(length = 300)
	private String email;
	
	@CreationTimestamp
	private LocalDateTime regDate; //고객이 등록될때 시간이 자동으로 생성되어서 등록
	
	//추가..권한...다대다 관계를 해소하기위한 조인 테이블(Association Entity)
	@ManyToMany
	@JoinTable(name="custom_role",
	           joinColumns = @JoinColumn(name="custom_id"),
	           inverseJoinColumns = @JoinColumn(name="role_id"))
	Set<Role> roles = new HashSet<>();

	@Override
	public String toString() {
		return "Custom [customId=" + customId + ", password=" + password + ", name=" + name + ", email=" + email
				+ ", regDate=" + regDate + "]";
	}	
	

	
}

/*
  Custom, Role 엔터티를 보면
  Custom은 Role은 여러개 가지는데
  Role쪽에서는 Custome 을 가지고 있지 않다.
  이것이 의미하는 것은?
  
  Custom에서 Role정보를 받아올수는 있지만
  Role에서 굳이 Custom정보를 받아올 필요가 없는 코드라는 생각이다.
  
  N : N 관계에서 이런 부분이 반드시 발생
  양방향성.. --> 단방향성으로 수정할수 있으면 무조건 수정
  JPA 코드가 더 안정적이게 된다.
 */


















