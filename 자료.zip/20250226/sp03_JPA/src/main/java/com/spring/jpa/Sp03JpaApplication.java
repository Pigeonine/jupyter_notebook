package com.spring.jpa;

import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cglib.core.internal.CustomizerRegistry;

import com.spring.jpa.entity.Board;
import com.spring.jpa.entity.Custom;
import com.spring.jpa.repository.BoardRepository;
import com.spring.jpa.repository.CustomRepository;
import com.spring.jpa.repository.RoleRepository;

import jakarta.transaction.Transactional;

@SpringBootApplication
public class Sp03JpaApplication implements CommandLineRunner{
	
	@Autowired
	private CustomRepository  customRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private BoardRepository boardRepository;
	
	@Transactional
	@Override
	public void run(String... args) throws Exception {
		//System.out.println(customRepository.getClass().getName());
		//Custom findC=customRepository.findById(2).orElseThrow();
		//Custom findC=customRepository.findById(2).orElseThrow(()-> new NoSuchElementException("아이디 존재하지 않음!!"));
		//Custom findC=customRepository.findById(2).orElseThrow(NoSuchElementException::new);
		/*
		Custom findC=customRepository.findById(2).get();
		System.out.println(findC);
		
		
		
		Custom c = new Custom();
		c.setName("CCC");
		c.setPassword("ccc");
		c.setEmail("ccc.google.com");
		c.setRegDate(LocalDateTime.now());
		customRepository.save(c);
		*/
		
		//customRepository.deleteById(6);
		
		/*
		customRepository.findAll()
		.forEach(c-> {
			System.out.println(c);
			System.out.println(c.getRoles());			
		});
		
		
		
		Custom findC=customRepository.findById(2).get();
		System.out.println("UPDATE 하기전 =>"+findC);
		
		findC.setPassword("1212");//....1차 캐시의 엔터티정보가 변경 | 스냅샷은  원래정보를 유지함
		System.out.println("UPDATE 한 후 =>"+findC); //페스워드가 변경...update sql문이 찍힐것이다.
		*/
		
		//Query Method Test...
		/*
		System.out.println(">>>>>>>>>>> findByName >>>>>>>>>>>>>>>>>>");
		customRepository.findByName("AAA").get()
		.forEach(c->System.out.println(c));
		
		System.out.println(">>>>>>>>>>> findByCustomIdBetween >>>>>>>>>>>>>>>>>>");
		
		customRepository.findByCustomIdBetween(1, 4)
		.forEach(c->System.out.println(c));
		
		System.out.println(">>>>>>>>>>>  findByRegDateAfter  >>>>>>>>>>>>>");
		
		customRepository.findByRegDateAfter(LocalDateTime.now().minusHours(13))
		.forEach(c->System.out.println(c));
		
		System.out.println(">>>>>>>>>>>  findByNameLike  >>>>>>>>>>>>>");
		
		customRepository.findByNameLike("김%")
		.forEach(c->System.out.println(c));
		
		System.out.println(">>>>>>>>>>>  findByCustomIdIn  >>>>>>>>>>>>>");
		customRepository.findByCustomIdIn(List.of(2,4,7))
		.forEach(c->System.out.println(c));
		
		
		roleRepository.findAll()
		.forEach(c->System.out.println(c));
		
		
		customRepository.findAll()
		.forEach(c->{
			System.out.println(c);
			System.out.println(c.getRoles());
		});
			
		
		
		boardRepository.findAll()
		.forEach(b-> {
			System.out.println(b);
			System.out.println(b.getCustom());			
		});
		*/	
		
		Board board = boardRepository.findById(1L).get();
		System.out.println(board);
	}	
	public static void main(String[] args) {
		SpringApplication.run(Sp03JpaApplication.class, args);
	}
}



















