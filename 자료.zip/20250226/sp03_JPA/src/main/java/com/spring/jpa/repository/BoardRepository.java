package com.spring.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.jpa.entity.Board;

public interface BoardRepository extends JpaRepository<Board, Long>{

}
