package com.spring.jpa.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity //해당 클래스는 디비테이블과 매핑되는 기술
@Table(name="custom") //현재 클래스명과 테이블명일 다를때 사용
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class Custom {
	
	@Id//유일한 값 pk
	@Column(name="custom_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer customId;
	
	@Column(length = 20)
	private String password;
	
	@Column(length = 30)
	private String name;
	
	@Column(length = 300)
	private String email;
	
	@CreationTimestamp
	private LocalDateTime regDate; //고객이 등록될때 시간이 자동으로 생성되어서 등록
}





