package com.spring.jpa;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.spring.jpa.entity.Custom;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;

//CommandLineRunner 스프링에서 제공하는 빈을 핸들링할때 사용하는 객체
@SpringBootApplication
public class Sp02JpaApplication implements CommandLineRunner{
	
	@Autowired
	EntityManagerFactory entityManagerFactory;
	
	@Override
	public void run(String... args) throws Exception {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		try {
			// 성공...commit
			transaction.begin();
			// persist(), find(), remove()
			//1. 고객등록
			/*
			Custom c = new Custom();
			c.setName("박정님");
			c.setPassword("2222");
			c.setEmail("diana@jaen.com");
			c.setRegDate(LocalDateTime.now());
			
			entityManager.persist(c);
			*/
			
			//2. 검색
			/*
			Custom findC=entityManager.find(Custom.class, 1);
			System.out.println("1번 고객 ==> "+findC);
			
			Custom findCC=entityManager.find(Custom.class, 1);
			System.out.println("1번 고객 다시 찾아옴==> "+findCC);			
			*/
			
			//3. 삭제
			/*
			Custom deleteC=entityManager.find(Custom.class, 3);
			entityManager.remove(deleteC);
			*/
			
			//4. 정보 수정...pk는 수정의 대상이 아니다
			//1번 고객의 패스워드를 1234--> sds로 변경
			//수정관련 함수는 제공되지 않는다!!
			/*
			Custom updateC=entityManager.find(Custom.class, 1);
			System.out.println("1번 수정 대상 고객 ==> "+updateC);
			
			updateC.setPassword("sds");
			System.out.println("1번 고객 ==> "+updateC);
			*/
			
			//5. 고객을 추가 + 정보를 변경 + 검색
			/*
			Custom c = new Custom();
			c.setName("James");
			c.setPassword("9000");
			c.setEmail("james@jaen.com");
			c.setRegDate(LocalDateTime.now());
			
			System.out.println("1.고객 등록 => "+c);				
			entityManager.persist(c);
			
			System.out.println("2.고객 정보 수정 => ");	
			c.setPassword("9090");//엔터티 원본과 스냇삿이 차이가 나서 변경감지가 일어난다...update호출
			
			System.out.println("3.고객 검색 => ");	
			entityManager.find(Custom.class, 5);
			
			
			System.out.println("4. 검색된 결과입니다. => "+c);	
			*/
			
			//6. persist, merge 차이점
			/*
			Custom c=entityManager.find(Custom.class, 5);
			System.out.println("find...call..1차 캐시에서 정보를 받아옴 "+c);
			
			c.setPassword("1111");
			System.out.println("update...call..1차 캐시에서 변경된 정보를 받아옴 "+c);
			
			//준영속 상태가 되면서 c관련한 sql 저장소 쿼리가 삭제..DB에 1111변경안됨
			entityManager. detach(c);
			System.out.println("준영속 상태.."+c);
			
			
			System.out.println("영속 상태로 진입함");
			//entityManager.persist(c); //update...
			entityManager.merge(c);
			*/
			transaction.commit();
		}catch(Exception e) {
			// 실패 ... rollback
			transaction.rollback();
		}finally {
			entityManager.close();
		}
		
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Sp02JpaApplication.class, args);
	}
}
