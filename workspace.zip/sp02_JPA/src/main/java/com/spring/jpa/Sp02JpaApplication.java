package com.spring.jpa;

import java.time.LocalDateTime;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.spring.jpa.entity.Custom;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;

@SpringBootApplication
public class Sp02JpaApplication implements CommandLineRunner {
	
	@Autowired
	EntityManagerFactory entityManagerFactory;
	
	@Override
	public void run(String... args) throws Exception {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		try {
			//성공..commit
			transaction.begin();
			// persist(), find(), remove()
			// 1. 고객등록
//			Custom c = new Custom();
//			c.setName("김상성");
//			c.setPassword("1234");
//			c.setEmail("sm@sds.com");
//			c.setRegDate(LocalDateTime.now());
//			
//			entityManager.persist(c);
//			// persist(), find(), remove()
//			// 1. 고객등록
//			Custom b = new Custom();
//			b.setName("이상성");
//			b.setPassword("123");
//			b.setEmail("sm@sd.com");
//			b.setRegDate(LocalDateTime.now());
//			
//			entityManager.persist(b);
//			// persist(), find(), remove()
//			// 1. 고객등록
//			Custom a = new Custom();
//			a.setName("박상성");
//			a.setPassword("12");
//			a.setEmail("sm@s.com");
//			a.setRegDate(LocalDateTime.now());
//			
//			entityManager.persist(a);
			
			
			//2. 검색
//			Custom findC = entityManager.find(Custom.class, 1);
//			System.out.println("1번 고객 ==> "+findC);
			
			//3. 삭제
//			Custom deleteC = entityManager.find(Custom.class, 3);
//			entityManager.remove(deleteC);
//			
			//4. 수정...pk는 수정의 대상이 아니다.
			//수정 관련 ㅎ마수는 제공되지 않는다.
			//1번 고객의 패스워드를 1234->sds로 변경하고자한다.
			Custom updateC = entityManager.find(Custom.class, 1);
			System.out.println("1번 고객 ==> "+updateC);
			updateC.setPassword("sds");//패스워드가 바뀌면서, 이것이 다르다고 인식해서 트랜잭션이 일어났다?
			System.out.println("1번 고객 ==> "+updateC);//Hibernate는 한번 처음에 하고, 여러 명렁어들을 각각 바로 시행하는 것이 아니라,
			//모아서 한번에 처리한다?(한번에 flush), commit 직전에 flush나오고 시행.
			
			transaction.commit();
		}catch(Exception e) {
			//실패...rollback
			transaction.rollback();
		} finally {
			entityManager.close();
		}
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Sp02JpaApplication.class, args);
	}

}
