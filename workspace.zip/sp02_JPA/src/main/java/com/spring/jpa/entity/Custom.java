package com.spring.jpa.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity //해당 클래스는 디비 테이블과 매핑되는 기술
@Table(name="custom") // 원래 클래스 명과 테이블명 다를 때 사용
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class Custom {
	@Id//유일한 값 pk
	@Column(name="custom_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer custionId;
	
	@Column(length = 20)
	private String Password;
	
	@Column(length = 30)
	private String name;
	
	@Column(length = 300)
	private String email;
	
	@CreationTimestamp
	private LocalDateTime regDate;//고객이 등록될때 시간이 자동으로 생성되어서 등록
}
