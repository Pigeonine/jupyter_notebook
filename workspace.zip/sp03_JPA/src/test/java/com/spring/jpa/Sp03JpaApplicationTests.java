package com.spring.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sp03JpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
