package com.spring.jpa;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;

import javax.swing.text.StyledEditorKit.ForegroundAction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.spring.jpa.entity.Custom;
import com.spring.jpa.entity.Role;
import com.spring.jpa.repository.BoardRepository;
import com.spring.jpa.repository.CustomRepository;
import com.spring.jpa.repository.RoleRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.transaction.Transactional;

@SpringBootApplication
public class Sp03JpaApplication implements CommandLineRunner{

	
	@Autowired
	private CustomRepository customRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private BoardRepository boardRepository;
	
	@Transactional
	@Override
	public void run(String... args) throws Exception {
//		System.out.println(customRepository.getClass().getName());
//		Custom findC = customRepository.findById(2).orElseThrow();
//		Custom findC = customRepository.findById(2).orElseThrow(()-> new NoSuchElementException("아이디 존재하지 않음"));
//		System.out.println(findC);
		
//		Custom c = new Custom();
//		c.setName("AAA");
//		c.setPassword("aaa");
//		c.setEmail("aaa.google.com");
//		c.setRegDate(LocalDateTime.now());
//		customRepository.save(c);
		
//		customRepository.deleteById(9);
		
//		customRepository.findAll()
//		.forEach(c -> System.out.println(c));
//		
//		Custom findC = customRepository.findById(2).get();
//		System.out.println("UPDATE 하기 전 ->" + findC);
//		
//		findC.setPassword("1212");
//		// 위처럼 하면 1차 캐시의 entity정보가 바뀐다. | 스냅샷은 원래 정보를 유지함 -> dirty상태 -> 변경을 감지하고 update문이 쓰기 저장소에 들어감
//		System.out.println("UPDATE 한 후 ->" + findC); // 패스워드 변경.. update sql문이 찍힐것이다. -> NO! 커밋이 안됐다. 트랜잭션 처리가 안되서 그렇다. 트랜잭션 처리는 어노테이션으로
//		
//		customRepository.findByName("AAA").get()
//		.forEach(c->System.out.println(c));
//		
//		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
//		
//		customRepository.findByCustomIdBetween(1, 4)
//		.forEach(c->System.out.println(c));
//		
//		System.out.println(">>>>>>>>>>>>>>>> findByRegDate >>>>>>>>>>>>>>");
//		
//		customRepository.findByRegDateAfter(LocalDateTime.now().minusHours(10L))
//		.forEach(c->System.out.println(c));
//		
//		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
//		
//		customRepository.findByNameStartingWith("김")
//		.forEach(c->System.out.println(c));
//		
//		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
//		
//		customRepository.findByNameStartingWithOrderByCustomIdDesc("김")
//		.forEach(c->System.out.println(c));
//		
//		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
//		customRepository.findByCustomIdIn(List.of(2,4,7))
//		.forEach(c->System.out.println(c));

//		customRepository.findAll()
//		.forEach(c -> {
//			System.out.println(c);
//			System.out.println(c.getRoles());
//		});
//		boardRepository.findAll()
//		.forEach(b->{	
//			System.out.println(b);
//			System.out.println(b.getCustomId());
//		});
		
		Board board = boardRepository.findById(1L).get();
		System.out.println(board);
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Sp03JpaApplication.class, args);
	}
}
