package spring.service.dao;

import java.util.List;

import spring.service.vo.Member;

//DM Access logic의 템플릿 기능
public interface MemberDAO {
	void register(Member vo);
	void delete(String id);
	void update(Member vo);
	Member getNumber(String id);
	List<Member> getAllMember();
}
