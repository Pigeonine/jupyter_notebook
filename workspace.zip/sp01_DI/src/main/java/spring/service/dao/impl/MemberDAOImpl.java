package spring.service.dao.impl;

import java.util.List;

import spring.service.dao.MemberDAO;
import spring.service.vo.Member;

//실제 디비 연결 기능 구현
//기능마다 connection 하나씩 받아서 logic 전개
//하나하나 기능이 하나하나의 클라이언트의 놔벽한 요청처리 단위 된다.

//DI 컨테이너가 만들도록?
public class MemberDAOImpl{

	public void register(Member vo) {
		// TODO Auto-generated method stub
		System.out.println("==== register number call ====");
		System.out.println(vo.getName()+" 님이 등록되었습니다..");
	}

	public void delete(String id) {
		// TODO Auto-generated method stub
		System.out.println("==== delete number call ====");
		System.out.println(id+" 님이 삭제되었습니다..");
	}
//
//	@Override
//	public void update(Member vo) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public Member getNumber(String id) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public List<Member> getAllMember() {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
