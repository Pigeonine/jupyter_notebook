package spring.service.dice.impl;

import java.util.Random;

import spring.service.dice.Dice;

public class DiceAImpl implements Dice{
	private int value;
	
	public DiceAImpl() {}
	
	public DiceAImpl(int value) {
		super();
		this.value = value;
	}
	public void selectedNumber()
	{
		value = new Random().nextInt(6)+1;
	}
	public int getValue() {
		return value;
	}
}
