package spring.service.dice.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

import spring.service.dao.impl.MemberDAOImpl;
import spring.service.dice.play.Player02;
import spring.service.vo.Member;
public class MemberTestAppUseSpring {
	public static void main(String[] args) {
		//DIContainer가 설정문서를 읽어서 빈들 생성+보관
		ClassPathXmlApplicationContext factory = 
				new ClassPathXmlApplicationContext("./config/member.xml");
		System.out.println("=============================");
		
		MemberDAOImpl dao = (MemberDAOImpl)factory.getBean("memberDAOImpl");
		//화면에서 정보 받았다 치고 데이터 값은 직접 생성
		Member member = new Member("11","11","김상성","잠실");
		dao.register(member);
		
		dao.delete("11");
	}
	
}//end of class