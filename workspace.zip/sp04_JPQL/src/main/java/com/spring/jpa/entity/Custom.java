package com.spring.jpa.entity;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity // 해당 클래스는 DB Table과 매핑되는 기술
@Table(name="custom") // 현재 클래스명과 테이블명이 다를 때 사용
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

@Data
public class Custom {
	
	@Id // pk 지정
	@Column(name="custom_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer customId;
	
	@Column(length = 20)
	private String password;
	
	@Column(length = 30)
	private String name;
	
	@Column(length = 300)
	private String email;
	
	@CreationTimestamp
	private LocalDateTime regDate;

	
	@ManyToMany
	@JoinTable(name="custom_role",
				joinColumns = @JoinColumn(name="custom_id"),
				inverseJoinColumns = @JoinColumn(name="rol_id"))
	Set<Role> roles = new HashSet<>();


	@Override
	public String toString() {
		return "Custom [customId=" + customId + ", password=" + password + ", name=" + name + ", email=" + email
				+ ", regDate=" + regDate + "]";
	}
	
	
}

/* 
Custom, Role 엔티티를 보면
Custom은 Role을 여러개 가지는데,
Role은 그렇지 않다.

Custom에서 Role정보를 받아올 수 는 있지만
Role에서 굳이 Custom정보를 받아올 필요 없음

N : N 관계에서 이런부분이 반드시 발생
양방향성에서 단방향성으로 수정하면 더 좋음
*/
