package com.spring.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.spring.jpa.entity.Board;

public interface BoardRepository extends JpaRepository<Board, Long>{

	/*
	 *	JPQL
	 *	SQL처럼 보이지만 SQL이 아니다. 
	 *  객체지향 언어이다.
	 *  JPQL에서 from절 뒤에 나오는 것은 테이블 명이 아니라 엔티티 클래스명이 온다!!!
	 *  
	 *  SELECT b FROM board b (x)
	 *  SELECT b FROM Board b (O)
	 *	
	 */
//	@Query(value = "SELECT b FROM Board b") //다 가져온다는 의미
//	@Query(value = "SELECT b FROM Board b JOIN b.custom") //Join 사용
	
	//JOIN FETCH :: 조인하면서 연관된 정보를 다 받아오는 기술
	//N+1문제를 해결하려면 일반 조인문이 아닌 jpql join fetch를 사용해야 한다. b.customId의 의미
	@Query(value = "SELECT b FROM Board b JOIN FETCH b.custom") //펫치 조인 사용으로 JPQL의 n+1문제 해결
//	@Query(value = "SELECT b FROM Board b JOIN FETCH Custom c ON b.customId = c.customId") //일반적인 조인 쿼리
	List<Board> getBoards(); //findAll()은 잘 안쓴다.(이러한 함수 만들어 사용)
	
	//전체 게시글의 갯수를 반환..
	@Query(value = "SELECT COUNT(boardId) FROM Board b")//디비 컬럼명이 아닌 @Id로 지정된 필드명
	Long getBoardCount();
	
	//관리자 권한을 가진 사람이 쓴 게시글 정보를 검색, 조건을 추가함(오버로딩), JPQL에서의 조인
	@Query(value = "SELCT b FROM Board b join b.custom c join c.roles r where r.name = :roleName") 
	List<Board> getBoards(String roleName);
}










