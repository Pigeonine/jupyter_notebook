package com.spring.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.jpa.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Integer>{

}
