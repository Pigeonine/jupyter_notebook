use tuna;
INSERT INTO guesthouse (name, location, capacity, description, tags, bg_img_url, host_img_url)
VALUES
('서울 한옥 게스트하우스', '서울 종로구', 12, '전통 한옥 분위기의 편안한 숙소입니다.', '파티 분위기의 숙소, 조용히 쉴 수 있는 숙소, 현실적이고 실용적인 숙소', 'https://example.com/bg1.jpg', 'https://example.com/host1.jpg'),
('부산 바다 전망 게스트하우스', '부산 해운대구', 8, '바다 전망과 현대적인 시설이 어우러진 숙소입니다.', '창의적인 활동이 있는 숙소, 이성적이고 체계적인 숙소, 따뜻하고 친절한 분위기의 숙소', 'https://example.com/bg2.jpg', 'https://example.com/host2.jpg'),
('제주 오름 게스트하우스', '제주 서귀포', 10, '제주의 자연을 만끽할 수 있는 숙소입니다.', '정해진 프로그램이 있는 숙소, 즉흥적인 활동이 있는 숙소, 활발한 분위기의 숙소', 'https://example.com/bg3.jpg', 'https://example.com/host3.jpg'),
('강릉 해변 게스트하우스', '강릉 경포대', 15, '해변 근처에서 즐기는 휴양 공간입니다.', '차분한 분위기의 숙소, 모험적인 활동이 있는 숙소, 안락하고 편안한 숙소', 'https://example.com/bg4.jpg', 'https://example.com/host4.jpg'),
('대구 도시형 게스트하우스', '대구 중구', 6, '도심 속의 안락한 쉼터입니다.', '영감을 주는 분위기의 숙소, 논리적이고 정돈된 숙소, 감성적이고 아늑한 숙소', 'https://example.com/bg5.jpg', 'https://example.com/host5.jpg'),
('인천 항구 게스트하우스', '인천 남동구', 9, '항구의 매력을 느낄 수 있는 숙소입니다.', '체계적으로 관리되는 숙소, 즉석에서 즐길 수 있는 활동이 있는 숙소, 친절한 서비스가 있는 숙소', 'https://example.com/bg6.jpg', 'https://example.com/host6.jpg'),
('광주 예술 게스트하우스', '광주 동구', 11, '예술과 문화가 살아있는 공간입니다.', '혼자서도 편안한 숙소, 세심하게 준비된 숙소, 상상력을 자극하는 활동이 있는 숙소', 'https://example.com/bg7.jpg', 'https://example.com/host7.jpg'),
('대전 현대 게스트하우스', '대전 유성구', 7, '현대적인 디자인과 편리한 위치의 숙소입니다.', '체계적으로 운영되는 숙소, 감정적으로 소통하는 분위기의 숙소, 정리된 환경의 숙소', 'https://example.com/bg8.jpg', 'https://example.com/host8.jpg'),
('울산 해안 게스트하우스', '울산 남구', 13, '해안가의 여유로운 분위기를 느낄 수 있는 숙소입니다.', '융통성 있는 활동이 있는 숙소, 소란스러운 분위기의 숙소, 편안하고 아늑한 숙소', 'https://example.com/bg9.jpg', 'https://example.com/host9.jpg'),
('수원 전통 게스트하우스', '수원 팔달구', 5, '전통과 현대가 조화를 이루는 숙소입니다.', '실용적이고 간편한 숙소, 비판적 사고를 자극하는 숙소, 감동적인 순간이 있는 숙소', 'https://example.com/bg10.jpg', 'https://example.com/host10.jpg'),
('창원 휴식 게스트하우스', '창원 의창구', 14, '편안한 휴식과 안락함을 제공하는 숙소입니다.', '정확한 일정이 있는 숙소, 즉흥적인 활동이 있는 숙소, 다정하고 친근한 분위기의 숙소', 'https://example.com/bg11.jpg', 'https://example.com/host11.jpg'),
('포항 바다 게스트하우스', '포항 북구', 10, '바다의 멋진 풍경을 감상할 수 있는 숙소입니다.', '혼자서도 잘 지낼 수 있는 숙소, 현실적이고 안정적인 숙소, 상상력 넘치는 활동이 있는 숙소', 'https://example.com/bg12.jpg', 'https://example.com/host12.jpg'),
('여수 낭만 게스트하우스', '여수 돌산', 12, '낭만적인 분위기와 함께하는 숙소입니다.', '이성적이고 논리적인 숙소, 따뜻하고 감성적인 숙소, 체계적으로 잘 관리되는 숙소', 'https://example.com/bg13.jpg', 'https://example.com/host13.jpg'),
('경주 역사 게스트하우스', '경주 시내', 8, '역사의 숨결이 느껴지는 숙소입니다.', '자유로운 분위기의 숙소, 파티 분위기의 숙소, 조용히 쉴 수 있는 숙소', 'https://example.com/bg14.jpg', 'https://example.com/host14.jpg'),
('전주 한옥 게스트하우스', '전주 한옥마을', 9, '전통 한옥의 멋을 살린 숙소입니다.', '현실적이고 실용적인 숙소, 창의적인 활동이 있는 숙소, 이성적이고 체계적인 숙소', 'https://example.com/bg15.jpg', 'https://example.com/host15.jpg'),
('부산 도심 게스트하우스', '부산 중구', 7, '도심 속의 편안한 휴식처입니다.', '따뜻하고 친절한 분위기의 숙소, 정해진 프로그램이 있는 숙소, 즉흥적인 활동이 있는 숙소', 'https://example.com/bg16.jpg', 'https://example.com/host16.jpg'),
('제주 감성 게스트하우스', '제주 제주시', 10, '감성적인 분위기와 자연이 어우러진 숙소입니다.', '활발한 분위기의 숙소, 차분한 분위기의 숙소, 모험적인 활동이 있는 숙소', 'https://example.com/bg17.jpg', 'https://example.com/host17.jpg'),
('서울 중심 게스트하우스', '서울 강남구', 6, '도심 속의 세련된 숙소입니다.', '안락하고 편안한 숙소, 영감을 주는 분위기의 숙소, 논리적이고 정돈된 숙소', 'https://example.com/bg18.jpg', 'https://example.com/host18.jpg'),
('부산 문화 게스트하우스', '부산 서면', 8, '문화와 예술이 살아있는 숙소입니다.', '감성적이고 아늑한 숙소, 체계적으로 관리되는 숙소, 즉석에서 즐길 수 있는 활동이 있는 숙소', 'https://example.com/bg19.jpg', 'https://example.com/host19.jpg'),
('제주 자연 게스트하우스', '제주 애월', 11, '자연과 어우러진 편안한 숙소입니다.', '친절한 서비스가 있는 숙소, 혼자서도 편안한 숙소, 세심하게 준비된 숙소', 'https://example.com/bg20.jpg', 'https://example.com/host20.jpg');
