package com.spring.jpa.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.spring.jpa.dto.BoardReq;
import com.spring.jpa.dto.BoardRes;
import com.spring.jpa.entity.Board;
import com.spring.jpa.exception.BoardSearchNotException;
import com.spring.jpa.exception.DMLException;
import com.spring.jpa.repository.BoardRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BoardService {
	final BoardRepository boardRepository;
	
	@Transactional
	public Board addBoard(BoardReq boardReq) {
		System.out.println("BoardReq==>"+boardReq);
		Board board=boardReq.toBoard(boardReq); //DTO--> Entity로 변경
		System.out.println("toBoard==>"+board);
		
		//save 하고나서 다시 Entity를 반환한다..
		return boardRepository.save(board);
	}
	
	//findBoard(Long id)
	/*
	 * 하나의 게시글 못찾으면 예외처리..	 * 
	 * 찾으면 Board를 바로 반환
	 * 최종적으로 리턴하기 전에 BoardRes로 변환해서 반환
	 */	
	public BoardRes findBoard(Long id) throws BoardSearchNotException{
		Board board= boardRepository.findById(id)				
			  .orElseThrow(()-> new BoardSearchNotException("Title - 검색에러","Message - 게시글 번호를 확인하세요"));
		return new BoardRes(board);
	}	
	
	//getBoard(String memberId)
	/*
	 * 특정 회원이 작성한 게시글 못찾으면 예외처리..
	 * 찾으면 List<Board>를 바로 반환
	   최종적으로 리턴하기 전에 BoardRes Collection으로 변환해서 반환 
	 * ::
	 * 람다형식~~!!
	 */	
	public List<BoardRes> getBoards(Integer id) throws BoardSearchNotException{
		List<Board> list = boardRepository.getBoards(id);
		if(list==null || list.isEmpty())
			throw new BoardSearchNotException("Title - getBoards에러", "Message - 특정 회원이 작성한 글 없습니다.");
		return list.stream().map(BoardRes::new).collect(Collectors.toList());
	}
	
	
	//findAll....성능상 안좋다
	//fetch join 을 사용한 getBoards	
	public List<BoardRes> getBoards() throws BoardSearchNotException{
		List<Board> list = boardRepository.getBoards();
		if(list==null || list.isEmpty())
			throw new BoardSearchNotException("Title - getBoards에러", "Message - 전체 게시글이 없습니다.");
		return list.stream().map(BoardRes::new).collect(Collectors.toList());
	}
	
	//updateBoard(Long id, BoardReq board)!!!..하나의 게시물 받아와서..필드변경....
	//Entity | Snapshot 변경감지해서 Update 쿼리를 호출한다.
	@Transactional
	public BoardRes updateBoard(Long id, BoardReq board) throws DMLException{
		Board boardEntity=boardRepository.findById(id)
				          .orElseThrow(()-> new DMLException("Title - updateBoard에러", "Message - 글번호 오류로 수정에 실패했습니다."));
		
		boardEntity.setTitle(board.getTitle());
		boardEntity.setContent(board.getContent());
		
		return new BoardRes(boardEntity);
	}
	
	//deleteBoard(Long id)....성공 / 실패
	@Transactional
	public String deleteBoard(Long id) throws DMLException{
		Board boardEntity=boardRepository.findById(id)
		          		                 .orElseThrow(()-> new DMLException("Title - deleteBoard에러","글번호 오류로 삭제에 실패했습니다.", HttpStatus.BAD_REQUEST));
		          		  
		boardRepository.delete(boardEntity);
		
		return "OK";
	}
}


