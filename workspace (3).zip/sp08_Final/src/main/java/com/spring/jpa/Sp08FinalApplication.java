package com.spring.jpa;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.spring.jpa.entity.Custom;
import com.spring.jpa.repository.BoardRepository;
import com.spring.jpa.repository.CustomRepository;

import jakarta.transaction.Transactional;

@SpringBootApplication
public class Sp08FinalApplication implements CommandLineRunner{
	
	@Autowired
	 CustomRepository customRepository;
	
	@Autowired
	BoardRepository boardRepository;
	
	
	@Transactional
	@Override
	public void run(String... args) throws Exception {
		
//		Custom c = new Custom();
//		c.setName("CCC");
//		c.setPassword("ccc");
//		c.setEmail("ccc.google.com");
//		c.setRegDate(LocalDateTime.now());
//		customRepository.save(c);
		
		
	}

	public static void main(String[] args) {
		SpringApplication.run(Sp08FinalApplication.class, args);
	}

	

}
