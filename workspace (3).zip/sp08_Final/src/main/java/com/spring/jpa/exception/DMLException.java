package com.spring.jpa.exception;

import org.springframework.http.HttpStatus;

import lombok.Getter;

@Getter
public class DMLException extends RuntimeException{
	private String message;
	private String title;
	private HttpStatus httpStatus;
	
	
	public DMLException(String message, String title, HttpStatus httpStatus) {
		this.message = message;
		this.title = title;
		this.httpStatus = httpStatus;
	}


	public DMLException(String title, String message) {
		this(title,message,HttpStatus.EXPECTATION_FAILED);
	} 

	
	
}
