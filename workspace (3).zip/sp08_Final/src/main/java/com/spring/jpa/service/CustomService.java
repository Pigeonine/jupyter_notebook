package com.spring.jpa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.spring.jpa.entity.Custom;
import com.spring.jpa.exception.CustomAuthenticationException;
import com.spring.jpa.repository.CustomRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CustomService { //customService	
	
	private final CustomRepository  customRepository;
	
	//1. 고객등록  
	@Transactional
	public void signUp(Custom custom) {
		Custom rCustom=customRepository.save(custom);
		System.out.println("signup Custom ==> "+rCustom);
	}

	//2. 아이디 중복확인  
	@Transactional
	public String duplicateCheck(Integer id) {
		Custom rCustom = customRepository.duplicateCheck(id);
		if(rCustom==null) return "아이디 사용가능";
		else return "사용불가 아이디";
	}
	
	//3. 로그인
	@Transactional
	public Custom signIn(Integer id, String password) throws Exception{
		Custom rCustom = customRepository.duplicateCheck(id);
		if(rCustom==null)
				throw new CustomAuthenticationException("Title - 인증오류","Message - 아이디를 다시 확인하세요");
		if(!rCustom.getPassword().equals(password))
			    throw new CustomAuthenticationException("Title - 인증오류","Message - 패스워드를 다시 확인하세요");
		return rCustom;
	}
}












