package com.spring.jpa.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@CrossOrigin(origins = {"*"}, maxAge = 3600) // 
@RestController
@RequestMapping("api/v1")
public class DeleteController {
	@DeleteMapping("/members/{id}")
	public ResponseEntity<?> deleteMember(@PathVariable String id){
		return ResponseEntity
				.status(202)
				.body(id+" , Delete OK~!!");
	}
	
}
