package com.spring.jpa.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.jpa.vo.Member;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.apache.catalina.connector.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
@RequestMapping("api/v1")
public class PutController {
	@PutMapping("/members")
	public Member updateMember(@RequestBody Member vo) {
		//TODO: process PUT request
		System.out.println("Service Call...UpdateMember...");
		return vo;
	}
	
	
	@PutMapping("/members2")
	public ResponseEntity<?> updateMember2(@RequestBody Member vo) {//ResponseEntity: ?넣으면 무엇이든지 입력 가능.
		//TODO: process PUT request
		System.out.println("Service Call...UpdateMember2...");
		return new ResponseEntity<>(vo,HttpStatus.OK);//OK:200번해당, member라는 정보 response로 보낸다. (상태값 + vo), 200...생성자 패턴
	}
	
	
	@PutMapping("/members3")
	public ResponseEntity<?> updateMember3(@RequestBody Member vo) {//ResponseEntity: ?넣으면 무엇이든지 입력 가능.
		//빌드 패턴
		System.out.println("Service Call...UpdateMember3...");
		return ResponseEntity
				.status(200)
				.body(vo);
	}
}
