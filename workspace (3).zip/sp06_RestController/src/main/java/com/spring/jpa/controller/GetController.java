package com.spring.jpa.controller;

import org.springframework.web.bind.annotation.RestController;

import com.spring.jpa.vo.Member;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;





//컨트롤러가 클라이언트에게 데이터를 반환한다.
@RestController 
public class GetController {
	
	//http://localhost:9000/members
	@GetMapping("/members")
	public String getMembers() {
		//서비스의 함수 -호출--> Repository 함수 호출 
		Member m = new Member("sds", "1234", "James", "Texas");
		return m.toString();
	}
	
	//http://localhost:9000/members/sds 
	@GetMapping("/members/{id}")
	public String getMember(@PathVariable String id) {
		return "Hello~~" + id;
	}
	//http://localhost:9000/member?name=james&address=Texas
	@GetMapping("/member")
	public String doMember(@RequestParam String name, @RequestParam String address) {
		return name + "님이 사는 곳은 " + address;
	}
}
