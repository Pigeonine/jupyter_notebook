package com.spring.jpa.controller;

import org.springframework.web.bind.annotation.RestController;

import com.spring.jpa.vo.Member;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;




@RestController
@RequestMapping("api/v1")
public class PostController {

	@PostMapping("/members")//member를 등록, 추가하는 서비스를 처리
	public String addMember(@RequestBody Member vo) {
		
		//Service의 함수가 call
		return vo.toString();
	}
	
}

//http://localhost:9000/api/v1/members -> 이러한 형식은 get만 가능,  (Requestly api 사용)
//Json에 내용 담아서 보냄(Post 방식)
