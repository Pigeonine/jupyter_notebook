package com.spring.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sp06RestControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sp06RestControllerApplication.class, args);
	}

}
