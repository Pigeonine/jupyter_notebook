package com.spring.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sp07JpaBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
