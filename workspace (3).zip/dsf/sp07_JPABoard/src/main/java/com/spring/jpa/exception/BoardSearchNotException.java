package com.spring.jpa.exception;

public class BoardSearchNotException extends Exception{
	public BoardSearchNotException() {
		this("This is BoardSearchNotException...");
	}
	public BoardSearchNotException(String message) {
		super(message);
	}
}
