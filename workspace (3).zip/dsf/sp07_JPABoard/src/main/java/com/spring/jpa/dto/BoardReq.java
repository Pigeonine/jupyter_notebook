package com.spring.jpa.dto;

import com.spring.jpa.entity.Board;
import com.spring.jpa.entity.Custom;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
//customId가 있어야 게시글 작성 할수 있다!!
public class BoardReq {
	
	private String title;
	private String content;
	private Integer customId;
	
    public Board toBoard(BoardReq boardReq){
 
        return Board.builder()
        		    .title(boardReq.getTitle())
        		    .content(boardReq.getContent())
        		    .custom(Custom.builder().customId(boardReq.customId).build())
                    .build();
    }
}
