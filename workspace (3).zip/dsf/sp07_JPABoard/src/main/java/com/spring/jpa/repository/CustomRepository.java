package com.spring.jpa.repository;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.spring.jpa.entity.Custom;

public interface CustomRepository extends JpaRepository<Custom, Integer>{
	/*
	   아무것도 작성 안해도 기본적인 이런 함수를 바로 사용할수 있다.
	   save()--> persist()
	   findByid() --> find()
	   findAll() --> find()
	   deleteById() -->remove()
	   delete() --> remove()
	 */
	// JPA Query Method...
	/*
	 * 1.대부분 findBy 로 시작
	 * 2. 이름규칙이 아주 중요..이것만 정확하게 작성하면 알아서 sql문 자동 생성
	 * 3. ORM방식이기 때문에 메소드명이 CamelCase를 따른다.
	 */
	
	//1. 특정한 고객이름으로 검색하는 기능
	Optional<List<Custom>>  findByName(String name);
	
	//2. 이름이 김삼성이고 이메일이 sds@google.com 인 사람을 검색
	Custom findByNameAndEmail(String name, String email);
	List<Custom> findByNameOrEmail(String name, String email);
	
	//3. 고객의 아이디가 1~ 4사이에 있는 고객을 검색
	List<Custom> findByCustomIdBetween(int id1, int id2);
	
	//4. 고객의 아이디가 3보다 작은 아이디를 가지는 고객을 검색
	List<Custom> findByCustomIdLessThanEqual(int id);
	List<Custom> findByCustomIdLessThan(int id);
	
	//5. 고객등록일자가 어제 이후에 등록된 고객만 검색
	List<Custom> findByRegDateAfter(LocalDateTime localDateTime);
	List<Custom> findByRegDateBefore(LocalDateTime localDateTime);
	
	//6. 고객이름이 김씨로 시작하는 고객을 검색
	List<Custom> findByNameLike(String startName); //값에 %를 직접 입력해야한다...주의!!
	List<Custom> findByNameStartingWith(String startName); //와일드카드가 적용되는 기능!!
	
	//7. 6번 + 정렬 (고객 아이디로 내림차순)
	// A로 시작하는 고객이름을 검색...customId로 내림차순정렬...
	List<Custom> findByNameStartingWithOrderByCustomIdDesc(String name);
	
	//8. 고객아이디가 2,4,7번인 고객들을 검색...
	List<Custom> findByCustomIdIn(Collection<Integer> ids);
	
	//9.  아이디와 패스워드로 고객을 검색...로그인
	Custom findByCustomIdAndPassword(Integer id, String password);
	
	//10.
	/*
	 Native Query
	 영속성 컴텍스트를 거치지 않고 데이타베이스에 직접 접근해서 실행되는 SQL
	 SQL쿼리 실행에 더 많은 제어를 제공하고 디비 특화되어져서 사용
	 
	 JPA로 진행하기 복잡하거나 난해한 쿼리를 실행해야 하는 경우
	 엔터티 내용을 업데이트 해야하는 경우
	 */
	@Query(value = "SELECT password FROM custom WHERE password=?", nativeQuery = true)
	String pwdExits(String password);
	
	//아이디 중복확인
	//@Query(value = "SELECT c FROM Custom c WHERE c.customId = ?1")
    @Query(value = "SELECT c FROM Custom c WHERE c.customId = :id")
    Custom duplicateCheck(Integer id);
	
}


















































