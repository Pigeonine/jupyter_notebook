package com.spring.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sp07JpaBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sp07JpaBoardApplication.class, args);
	}

}
