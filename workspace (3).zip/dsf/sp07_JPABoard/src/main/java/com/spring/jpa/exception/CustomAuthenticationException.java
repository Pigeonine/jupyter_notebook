package com.spring.jpa.exception;

public class CustomAuthenticationException extends Exception{
	public CustomAuthenticationException() {
		this("This is CustomAuthenticationException...");
	}
	public CustomAuthenticationException(String message) {
		super(message);
	}
}
