package com.spring.jpa.dto;

import com.spring.jpa.entity.Board;
import com.spring.jpa.entity.Custom;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class BoardRes {
	
	private long id;
	private String title;
	private String content;
	private String regDate;
	private CustomRes custom;
	
	public BoardRes(Board board) {
        id = board.getBoardId();
        title=board.getTitle();
        content=board.getContent();
        regDate=board.getRegDate().toString();
        custom=new CustomRes(board.getCustom().getCustomId(),
                             board.getCustom().getName(),
                             board.getCustom().getPassword(),
                             board.getCustom().getEmail());

   }
	//빌드 패턴
	/*
	public BoardRes toBoardRes(Board board){
	       return BoardRes.builder()
	               .id(board.getBoardId())
	               .title(board.getTitle())
	               .content(board.getContent())
	               .regDate(board.getRegDate().toString())
	               .custom(new CustomRes(board.getCustom().getCustomId() , 
	            		                 board.getCustom().getName(),
	            		                 board.getCustom().getPassword(),
	                                     board.getCustom().getEmail())
	               .build();
	   }
	  */
}
