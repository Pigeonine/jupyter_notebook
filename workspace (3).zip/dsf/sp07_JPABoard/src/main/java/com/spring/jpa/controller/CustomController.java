package com.spring.jpa.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.jpa.entity.Custom;
import com.spring.jpa.service.CustomService;

import lombok.RequiredArgsConstructor;

@CrossOrigin(origins ="{*}", maxAge = 6000)
@RestController
@RequiredArgsConstructor
public class CustomController {
	
	final CustomService customService;
	
	//signUp..회원가입
	@PostMapping("/members")
	public String signUp(@RequestBody Custom custom) {
		customService.signUp(custom);
		return "Register OK~~!!";
	}
	
	//duplicateCheck...아이디 중복
	@GetMapping("/members/{id}")
	public String duplicateCheck(@PathVariable Integer id) {
		return customService.duplicateCheck(id); //"아이디 사용불가" | "아이디 사용 가능"
	}
	
	//signIn...로그인
	@PostMapping("/members/login")
	public Custom signIn(@RequestBody Custom custom) throws Exception{
		Custom rCustom=customService.signIn(custom.getCustomId(), custom.getPassword());
		return rCustom; //rCustom 데이타가 클라이언트로 전송...Json으로 변환되어서 정보가 날라간다..
	}
}















