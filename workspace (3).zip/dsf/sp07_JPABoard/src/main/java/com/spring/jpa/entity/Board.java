package com.spring.jpa.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
//@ToString
public class Board {
	@Id
	@Column(name="board_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long boardId;
	
	@Column(length = 100)
	private String title;
	
	@Lob//varchar보다 더 큰 용량의 데이타를 담을수 있다.
	private String content; //Text Type
	
	private int count;
	
	@CreationTimestamp
	private LocalDateTime regDate;
	
	//Association Entity 추가하기..
	// 한명의 고객이 여러개의 게시글을 작성...OneToMany  |  ManyToOne
	//엔터티 관계를 지정할때는 FetchType 속성이 있다
	//@ManyToOne(fetch = FetchType.EAGER)//무조건 가져와라
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="custom_id")
	private Custom custom;
	
	/*
	 findAll() 인경우 EAGER, LAZY -- 조인 안걸린다.
	 findById() 인경우 EAGER에만 레프트조인이 걸린다.
	 전체검색 /  한 건검색이 서로 다르게 FetchType이 작동한다
	 
	 무조건 EAGER
	 무조건 LAZY
	 
	 엔터티의 결합관계에서 굳이 함꼐 가져와야할 필요가 없을때는 LAZY방식을 사용하는것이
	 메모리 , 성능측면에서 좋을수 있다.
	 
	 */
	
	
	//Custom 부분을 제외
	
	@Override
	public String toString() {
		return "Board [boardId=" + boardId + ", title=" + title + ", content=" + content + ", count=" + count
				+ ", regDate=" + regDate + "]";
	}
	
	
}












