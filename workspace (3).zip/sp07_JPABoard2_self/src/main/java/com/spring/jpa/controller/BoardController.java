package com.spring.jpa.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.jpa.dto.BoardReq;
import com.spring.jpa.service.BoardService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class BoardController {
	final BoardService boardService;
	@GetMapping("/boards")
//    public ResponseEntity<?> findAll() throws Exception{
//
//    }
//	 //특정한 사람이 작성한 게시물 조회            
//    @GetMapping("/boards/member/{id}")
//    public ResponseEntity<?> getBoard(@PathVariable Integer id)throws Exception{
//        
//    }
//    
//    // 글번호에 해당하는 게시물 조회
//    @GetMapping("/boards/{id}")
//    public ResponseEntity<?> findById(@PathVariable Long id) throws Exception{
//        
//    }
//    //게시물 등록!! BoardReq
//    @PostMapping("/boards")
//    public ResponseEntity<?> save(@RequestBody BoardReq board){
//        
//    }
//
//    //글번호에 해당하는 게시물 수정 !! BoardReq
//    @PutMapping("/boards/{id}")
//    public ResponseEntity<?> update(@PathVariable Long id,@RequestBody BoardReq board)throws Exception{
//        
//    }
//    //글번호에 해당하는 게시물 삭제        
//    @DeleteMapping("/boards/{id}")
//    public ResponseEntity<?> delete(@PathVariable Long id)throws Exception{        
//        
//    }
}
