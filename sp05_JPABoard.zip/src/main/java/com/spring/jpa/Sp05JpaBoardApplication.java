package com.spring.jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.transaction.Transactional;

@SpringBootApplication
public class Sp05JpaBoardApplication implements CommandLineRunner{
	@Autowired
	
	
	public static void main(String[] args) {
		SpringApplication.run(Sp05JpaBoardApplication.class, args);
	}
	
	@Transactional
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
